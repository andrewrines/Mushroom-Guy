// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MushroomMan.h"
#include "MyCharacter.generated.h"

UCLASS()
class MUSHROOMMAN_API AMyCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AMyCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Tick Functions //

	void MoveInputTick(float DeltaTime);
	void CameraInputTick(float DeltaTime);

	void IdleStateTick(float DeltaTime);
	void GlideStateTick(float DeltaTime);
	void JumpReadyStateTick(float DeltaTime);

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	// Input Mapping

	void MoveX(float Value);
	void MoveY(float Value);

	void CameraX(float Value);
	void CameraY(float Value);

	FVector2D MoveInputVector;
	FVector2D CameraInputVector;

	FVector2D CameraTurnRate = FVector2D(90.0f, 45.0f);
	FVector2D CameraSensitivity = FVector2D(1.0f, 1.0f);

	void JumpPressed();
	void JumpReleased();

	bool bJumpPressed = false;

	void Action1Pressed();
	void Action1Released();

	bool bAction1Pressed = false;


	// Parse Input //

	FVector GetMoveVector();

	// Actions / States //

	UPROPERTY(BlueprintReadOnly)
	ECharacterState MyCharacterState = ECharacterState::EIdle;

	void SwitchStates(ECharacterState NewState);

	void RequestJump(bool bPressed);

	void Action1Request(bool bPressed);

	void RequestGlide();

	float IdleWalkSpeed = 600.0f;

	float JumpReadyWalkSpeed = 200.0f;


	// Collect / Inventory / Spores //
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spore Actions")
	float Spores = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spore Actions")
	float MaxSpores = 10.0f;


	float SporeCharge = 0.0f;

	UPROPERTY(EditAnywhere,Category="Spore Actions")
	float SporeJumpStrength = 500.0f;

	UFUNCTION(BlueprintCallable)
	float GetSpores(float AddSpores);

};
