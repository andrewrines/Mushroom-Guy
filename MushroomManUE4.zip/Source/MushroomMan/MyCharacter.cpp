// Fill out your copyright notice in the Description page of Project Settings.


#include "MyCharacter.h"
#include "Components/InputComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"

// Sets default values
AMyCharacter::AMyCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	bUseControllerRotationYaw = false;

	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 720.0f, 0.0f);

}

// Called when the game starts or when spawned
void AMyCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMyCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	MoveInputTick(DeltaTime);
	CameraInputTick(DeltaTime);

	switch (MyCharacterState)
	{
	case ECharacterState::EIdle:
		IdleStateTick(DeltaTime);
		break;
	case ECharacterState::EGliding:
		GlideStateTick(DeltaTime);
		break;
	case ECharacterState::EJumpReady:
		JumpReadyStateTick(DeltaTime);
		break;
	default:
		break;
	}
}

// Tick Functions //

void AMyCharacter::MoveInputTick(float DeltaTime) {
	FVector MoveVector = GetMoveVector();

	if (MoveVector.Size() > 0.0f) {
		AddMovementInput(MoveVector, MoveVector.Size());
	}
}

void AMyCharacter::CameraInputTick(float DeltaTime) {
	AddControllerPitchInput(CameraInputVector.Y * CameraTurnRate.Y * CameraSensitivity.Y * DeltaTime);
	AddControllerYawInput(CameraInputVector.X * CameraTurnRate.X * CameraSensitivity.X * DeltaTime);

}

void AMyCharacter::IdleStateTick(float DeltaTime) {
	GetCharacterMovement()->MaxWalkSpeed = IdleWalkSpeed;
	GetCharacterMovement()->GravityScale = 1.0f;
}

void AMyCharacter::GlideStateTick(float DeltaTime) {
	GetCharacterMovement()->MaxWalkSpeed = IdleWalkSpeed;

	if (GetCharacterMovement()->IsFalling() && bJumpPressed) {
		FVector V = GetCharacterMovement()->Velocity;

		if (V.Z >= 0.0f) {
			GetCharacterMovement()->GravityScale = 1.0f;
		}
		else {
			GetCharacterMovement()->GravityScale = 0.1f;
		}
		
	}
	else if (!(bJumpPressed)) {
		GetCharacterMovement()->GravityScale = 1.0f;
		SwitchStates(ECharacterState::EIdle);
	}
	else {
		GetCharacterMovement()->GravityScale = 1.0f;
		SwitchStates(ECharacterState::EIdle);
	}
}

void AMyCharacter::JumpReadyStateTick(float DeltaTime) {
	GetCharacterMovement()->GravityScale = 1.0f;
	GetCharacterMovement()->MaxWalkSpeed = JumpReadyWalkSpeed;
	
	if (Spores > 0.0f) {
		Spores -= DeltaTime;
		SporeCharge += DeltaTime;

		if (Spores <= 0.0f) {
			SwitchStates(ECharacterState::EIdle);
			LaunchCharacter(FVector(0.0f, 0.0f, SporeJumpStrength) * SporeCharge * 2.0f, false, false);
			SporeCharge = 0.0f;
			Spores = 0.0f;
		}
	}
	else {
		SwitchStates(ECharacterState::EIdle);
		LaunchCharacter(FVector(0.0f, 0.0f, SporeJumpStrength) * SporeCharge * 2.0f, false, false);
		SporeCharge = 0.0f;
		Spores = 0.0f;
	}
}

// Called to bind functionality to input
void AMyCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis("MoveX", this, &AMyCharacter::MoveX);
	PlayerInputComponent->BindAxis("MoveY", this, &AMyCharacter::MoveY);

	PlayerInputComponent->BindAxis("CameraX", this, &AMyCharacter::CameraX);
	PlayerInputComponent->BindAxis("CameraY", this, &AMyCharacter::CameraY);

	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AMyCharacter::JumpPressed);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &AMyCharacter::JumpReleased);

	PlayerInputComponent->BindAction("Action1", IE_Pressed, this, &AMyCharacter::Action1Pressed);
	PlayerInputComponent->BindAction("Action1", IE_Released, this, &AMyCharacter::Action1Released);

}

// Input Mapping //

void AMyCharacter::MoveX(float Value) {
	MoveInputVector.X = Value;
}

void AMyCharacter::MoveY(float Value) {
	MoveInputVector.Y = Value;
}

void AMyCharacter::CameraX(float Value) {
	CameraInputVector.X = Value;
}

void AMyCharacter::CameraY(float Value) {
	CameraInputVector.Y = Value;
}

void AMyCharacter::JumpPressed() {
	bJumpPressed = true;

	RequestJump(true);
}

void AMyCharacter::JumpReleased() {
	bJumpPressed = false;

	RequestJump(false);
}

void AMyCharacter::Action1Pressed() {
	bAction1Pressed = true;

	Action1Request(true);
}

void AMyCharacter::Action1Released() {
	bAction1Pressed = false;

	Action1Request(false);
}

// Parse Input //

FVector AMyCharacter::GetMoveVector() {
	FVector MoveVector;

	FRotator R = GetControlRotation();
	R.Pitch = 0.0f;

	MoveVector = (UKismetMathLibrary::GetRightVector(R) * MoveInputVector.X) + (UKismetMathLibrary::GetForwardVector(R) * MoveInputVector.Y);

	return MoveVector;
}

// Actions //

void AMyCharacter::SwitchStates(ECharacterState NewState) {
	MyCharacterState = NewState;
}

void AMyCharacter::RequestJump(bool bPressed) {
	if (bPressed) {
		if (GetCharacterMovement()->IsFalling()) {

			RequestGlide();
		}
		else {
			Jump();
			//SwitchStates(ECharacterState::EJumpReady);

		}
	}
	else {
		
	}
	
}

void AMyCharacter::Action1Request(bool bPressed) {
	if (bPressed) {
		switch (MyCharacterState)
		{
		case ECharacterState::EIdle:
			SwitchStates(ECharacterState::EJumpReady);
			break;
		case ECharacterState::EGliding:
			SwitchStates(ECharacterState::EJumpReady);
			break;
		case ECharacterState::EJumpReady:
			break;
		default:
			break;
		}
	}
	else {
		switch (MyCharacterState)
		{
		case ECharacterState::EIdle:
			break;
		case ECharacterState::EGliding:
			break;
		case ECharacterState::EJumpReady:
			SwitchStates(ECharacterState::EIdle);
			LaunchCharacter(FVector(0.0f, 0.0f, SporeJumpStrength) * SporeCharge * 2.0f, false, false);
			SporeCharge = 0.0f;
			Spores = 0.0f;
			break;
		default:
			break;
		}
	}
}

void AMyCharacter::RequestGlide() {
	if (GetCharacterMovement()->IsFalling()) {
		
		SwitchStates(ECharacterState::EGliding);
	}
	else {

	}
}

// Spores //

float AMyCharacter::GetSpores(float AddSpores) {
	float SporesToAdd = MaxSpores - Spores;

	if (AddSpores <= SporesToAdd) {
		Spores += AddSpores;
		return AddSpores;
	}
	else {
		Spores += SporesToAdd;
		return (SporesToAdd);
	}
}